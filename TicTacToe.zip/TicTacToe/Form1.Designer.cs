﻿namespace TicTacToe
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnONE = new System.Windows.Forms.Button();
            this.btnTWO = new System.Windows.Forms.Button();
            this.btnTHREE = new System.Windows.Forms.Button();
            this.btnFOUR = new System.Windows.Forms.Button();
            this.btnFIVE = new System.Windows.Forms.Button();
            this.btnSIX = new System.Windows.Forms.Button();
            this.btnNINE = new System.Windows.Forms.Button();
            this.btnEIGHT = new System.Windows.Forms.Button();
            this.btnSEVEN = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.btnStart = new System.Windows.Forms.Button();
            this.btnQuit = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.lblCPUScore = new System.Windows.Forms.Label();
            this.lblCPUNum = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblPlScore = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblDrawScore = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            this.SuspendLayout();
            // 
            // btnONE
            // 
            this.btnONE.Font = new System.Drawing.Font("Palatino Linotype", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnONE.Location = new System.Drawing.Point(282, 81);
            this.btnONE.Name = "btnONE";
            this.btnONE.Size = new System.Drawing.Size(75, 74);
            this.btnONE.TabIndex = 0;
            this.btnONE.Text = "?";
            this.btnONE.UseVisualStyleBackColor = true;
            this.btnONE.Click += new System.EventHandler(this.btnONE_Click);
            // 
            // btnTWO
            // 
            this.btnTWO.Font = new System.Drawing.Font("Palatino Linotype", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTWO.Location = new System.Drawing.Point(363, 81);
            this.btnTWO.Name = "btnTWO";
            this.btnTWO.Size = new System.Drawing.Size(75, 74);
            this.btnTWO.TabIndex = 1;
            this.btnTWO.Text = "?";
            this.btnTWO.UseVisualStyleBackColor = true;
            this.btnTWO.Click += new System.EventHandler(this.btnTWO_Click);
            // 
            // btnTHREE
            // 
            this.btnTHREE.Font = new System.Drawing.Font("Palatino Linotype", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTHREE.Location = new System.Drawing.Point(444, 81);
            this.btnTHREE.Name = "btnTHREE";
            this.btnTHREE.Size = new System.Drawing.Size(75, 74);
            this.btnTHREE.TabIndex = 2;
            this.btnTHREE.Text = "?";
            this.btnTHREE.UseVisualStyleBackColor = true;
            this.btnTHREE.Click += new System.EventHandler(this.btnTHREE_Click);
            // 
            // btnFOUR
            // 
            this.btnFOUR.Font = new System.Drawing.Font("Palatino Linotype", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFOUR.Location = new System.Drawing.Point(282, 161);
            this.btnFOUR.Name = "btnFOUR";
            this.btnFOUR.Size = new System.Drawing.Size(75, 74);
            this.btnFOUR.TabIndex = 3;
            this.btnFOUR.Text = "?";
            this.btnFOUR.UseVisualStyleBackColor = true;
            this.btnFOUR.Click += new System.EventHandler(this.btnFOUR_Click);
            // 
            // btnFIVE
            // 
            this.btnFIVE.Font = new System.Drawing.Font("Palatino Linotype", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFIVE.Location = new System.Drawing.Point(363, 161);
            this.btnFIVE.Name = "btnFIVE";
            this.btnFIVE.Size = new System.Drawing.Size(75, 74);
            this.btnFIVE.TabIndex = 4;
            this.btnFIVE.Text = "?";
            this.btnFIVE.UseVisualStyleBackColor = true;
            this.btnFIVE.Click += new System.EventHandler(this.btnFIVE_Click);
            // 
            // btnSIX
            // 
            this.btnSIX.Font = new System.Drawing.Font("Palatino Linotype", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSIX.Location = new System.Drawing.Point(444, 161);
            this.btnSIX.Name = "btnSIX";
            this.btnSIX.Size = new System.Drawing.Size(75, 74);
            this.btnSIX.TabIndex = 5;
            this.btnSIX.Text = "?";
            this.btnSIX.UseVisualStyleBackColor = true;
            this.btnSIX.Click += new System.EventHandler(this.btnSIX_Click);
            // 
            // btnNINE
            // 
            this.btnNINE.Font = new System.Drawing.Font("Palatino Linotype", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNINE.Location = new System.Drawing.Point(444, 241);
            this.btnNINE.Name = "btnNINE";
            this.btnNINE.Size = new System.Drawing.Size(75, 74);
            this.btnNINE.TabIndex = 8;
            this.btnNINE.Text = "?";
            this.btnNINE.UseVisualStyleBackColor = true;
            this.btnNINE.Click += new System.EventHandler(this.btnNINE_Click);
            // 
            // btnEIGHT
            // 
            this.btnEIGHT.Font = new System.Drawing.Font("Palatino Linotype", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEIGHT.Location = new System.Drawing.Point(363, 241);
            this.btnEIGHT.Name = "btnEIGHT";
            this.btnEIGHT.Size = new System.Drawing.Size(75, 74);
            this.btnEIGHT.TabIndex = 7;
            this.btnEIGHT.Text = "?";
            this.btnEIGHT.UseVisualStyleBackColor = true;
            this.btnEIGHT.Click += new System.EventHandler(this.btnEIGHT_Click);
            // 
            // btnSEVEN
            // 
            this.btnSEVEN.Font = new System.Drawing.Font("Palatino Linotype", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSEVEN.Location = new System.Drawing.Point(282, 241);
            this.btnSEVEN.Name = "btnSEVEN";
            this.btnSEVEN.Size = new System.Drawing.Size(75, 74);
            this.btnSEVEN.TabIndex = 6;
            this.btnSEVEN.Text = "?";
            this.btnSEVEN.UseVisualStyleBackColor = true;
            this.btnSEVEN.Click += new System.EventHandler(this.btnSEVEN_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.pictureBox1.Location = new System.Drawing.Point(434, 81);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(19, 234);
            this.pictureBox1.TabIndex = 9;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.pictureBox2.Location = new System.Drawing.Point(347, 81);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(20, 234);
            this.pictureBox2.TabIndex = 10;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.pictureBox5.Location = new System.Drawing.Point(282, 152);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(236, 10);
            this.pictureBox5.TabIndex = 13;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.pictureBox6.Location = new System.Drawing.Point(282, 233);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(236, 11);
            this.pictureBox6.TabIndex = 14;
            this.pictureBox6.TabStop = false;
            // 
            // btnStart
            // 
            this.btnStart.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnStart.Location = new System.Drawing.Point(299, 332);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(95, 42);
            this.btnStart.TabIndex = 15;
            this.btnStart.Text = "Restart";
            this.btnStart.UseVisualStyleBackColor = false;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // btnQuit
            // 
            this.btnQuit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnQuit.Location = new System.Drawing.Point(400, 332);
            this.btnQuit.Name = "btnQuit";
            this.btnQuit.Size = new System.Drawing.Size(95, 42);
            this.btnQuit.TabIndex = 16;
            this.btnQuit.Text = "Quit";
            this.btnQuit.UseVisualStyleBackColor = false;
            this.btnQuit.Click += new System.EventHandler(this.btnQuit_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Stencil", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(255, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(310, 57);
            this.label1.TabIndex = 18;
            this.label1.Text = "Tic Tac Toe";
            this.label1.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // lblCPUScore
            // 
            this.lblCPUScore.AutoSize = true;
            this.lblCPUScore.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCPUScore.ForeColor = System.Drawing.Color.Firebrick;
            this.lblCPUScore.Location = new System.Drawing.Point(565, 81);
            this.lblCPUScore.Name = "lblCPUScore";
            this.lblCPUScore.Size = new System.Drawing.Size(93, 22);
            this.lblCPUScore.TabIndex = 19;
            this.lblCPUScore.Text = "CPU Score:";
            this.lblCPUScore.Click += new System.EventHandler(this.label2_Click);
            // 
            // lblCPUNum
            // 
            this.lblCPUNum.AutoSize = true;
            this.lblCPUNum.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCPUNum.ForeColor = System.Drawing.Color.Firebrick;
            this.lblCPUNum.Location = new System.Drawing.Point(652, 81);
            this.lblCPUNum.Name = "lblCPUNum";
            this.lblCPUNum.Size = new System.Drawing.Size(18, 22);
            this.lblCPUNum.TabIndex = 20;
            this.lblCPUNum.Text = "0";
            this.lblCPUNum.Click += new System.EventHandler(this.label3_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.SeaGreen;
            this.label2.Location = new System.Drawing.Point(565, 110);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(121, 22);
            this.label2.TabIndex = 21;
            this.label2.Text = "PLAYER Score:";
            // 
            // lblPlScore
            // 
            this.lblPlScore.AutoSize = true;
            this.lblPlScore.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPlScore.ForeColor = System.Drawing.Color.SeaGreen;
            this.lblPlScore.Location = new System.Drawing.Point(681, 110);
            this.lblPlScore.Name = "lblPlScore";
            this.lblPlScore.Size = new System.Drawing.Size(18, 22);
            this.lblPlScore.TabIndex = 22;
            this.lblPlScore.Text = "0";
            this.lblPlScore.Click += new System.EventHandler(this.lblPlScore_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Blue;
            this.label3.Location = new System.Drawing.Point(565, 140);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 22);
            this.label3.TabIndex = 23;
            this.label3.Text = "DRAW: ";
            // 
            // lblDrawScore
            // 
            this.lblDrawScore.AutoSize = true;
            this.lblDrawScore.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDrawScore.ForeColor = System.Drawing.Color.Blue;
            this.lblDrawScore.Location = new System.Drawing.Point(628, 140);
            this.lblDrawScore.Name = "lblDrawScore";
            this.lblDrawScore.Size = new System.Drawing.Size(18, 22);
            this.lblDrawScore.TabIndex = 24;
            this.lblDrawScore.Text = "0";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblDrawScore);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lblPlScore);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblCPUNum);
            this.Controls.Add(this.lblCPUScore);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnQuit);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnNINE);
            this.Controls.Add(this.btnEIGHT);
            this.Controls.Add(this.btnSEVEN);
            this.Controls.Add(this.btnSIX);
            this.Controls.Add(this.btnFIVE);
            this.Controls.Add(this.btnFOUR);
            this.Controls.Add(this.btnTHREE);
            this.Controls.Add(this.btnTWO);
            this.Controls.Add(this.btnONE);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnONE;
        private System.Windows.Forms.Button btnTWO;
        private System.Windows.Forms.Button btnTHREE;
        private System.Windows.Forms.Button btnFOUR;
        private System.Windows.Forms.Button btnFIVE;
        private System.Windows.Forms.Button btnSIX;
        private System.Windows.Forms.Button btnNINE;
        private System.Windows.Forms.Button btnEIGHT;
        private System.Windows.Forms.Button btnSEVEN;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Button btnQuit;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblCPUScore;
        private System.Windows.Forms.Label lblCPUNum;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblPlScore;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblDrawScore;
    }
}

